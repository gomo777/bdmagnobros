package com.example.demo.service;

import java.util.List;

import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.demo.entities.magno;

@SpringBootApplication
public class magnoService {

	public magno Savemagno(magnoService magnoService) {
		// TODO Auto-generated method stub
		return null;
	}

	public magno getmagnoByid(Long clicodigo) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<magno> getAllmagno() {
		// TODO Auto-generated method stub
		return null;
	}



}
