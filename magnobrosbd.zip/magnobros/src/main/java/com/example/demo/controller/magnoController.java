package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.magno;
import com.example.demo.service.magnoService;

@RestController
@RequestMapping("/magno")
public class magnoController {
	private final magnoService magnoService;
	
	@Autowired
	public magnoController(magnoService magnoService) {
		this.magnoService = magnoService;
	}
	
	@PostMapping
	public magno createProduct(@RequestBody magno magno) {
		// return produtoService.saveProduto(produto);
		return magnoService.Savemagno(magnoService);
	}

	public magno Savemagno(com.example.demo.service.magnoService magnoService) {
		return magnoService.Savemagno(magnoService);
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<magno> getMagno(@PathVariable Long clicodigo) {
		magno magno = magnoService.getmagnoByid(clicodigo);
		if (magno != null) {
			return ResponseEntity.ok(magno);
		} else {
			return ResponseEntity.notFound().build();
		}
	}
	@GetMapping("/home")
	public String paginaInicial() {
		return "index"; // nome do seu arquivo HTML , (sem a extensão)
	}

	

	

}
